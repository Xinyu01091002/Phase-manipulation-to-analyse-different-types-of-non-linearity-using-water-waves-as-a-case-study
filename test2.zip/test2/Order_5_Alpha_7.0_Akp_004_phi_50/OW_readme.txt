Check phase separation T=-40.00Tp H=0.983667 dx=7.494288, dt=0.400000
A=1.431304,Akp=0.040000, kp=0.027947, lambda=224.828639, Tp=12.000000
lambda=30.000000 dx, T=30.000000 dt, cw=9.401604, CFL=0.501801, kd=4.191983
Last modified in 23-Aug-2024 21:41:54