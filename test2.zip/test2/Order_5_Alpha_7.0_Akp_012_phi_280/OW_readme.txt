Check phase separation T=-40.00Tp H=3.011756 dx=7.494288, dt=0.400000
A=4.293911,Akp=0.120000, kp=0.027947, lambda=224.828639, Tp=12.000000
lambda=30.000000 dx, T=30.000000 dt, cw=9.401604, CFL=0.501801, kd=4.191983
Last modified in 23-Aug-2024 22:00:08